package assistedpractice19;

import java.util.LinkedList;
import java.util.Queue;

public class queue {
	
	public static void main(String[] args) {
		Queue<Integer> qq=new LinkedList<>();
		
		qq.offer(1100);
		qq.offer(200);
		qq.add(5000);
		qq.add(5);
		
		System.out.println("After Insertion Queue");
		System.out.println(qq);
		
		while (!qq.isEmpty()) {
            int dq = qq.poll();
            System.out.println("Dequeued: " + dq);
        }

		System.out.println("Queue elements after removal");
        System.out.println(qq);
	}
}


