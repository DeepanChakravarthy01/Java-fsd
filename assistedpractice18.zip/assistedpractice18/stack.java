package assistedpractice18;
import java.util.Stack;

public class stack {
	
	public static void main(String[] args) {

		Stack<Integer> s1=new Stack<Integer>();
		
		//to push elements
		s1.push(2000);
		s1.push(3000);
		s1.push(4000);
		s1.push(5000);
		
		//print stack elements
		
		System.out.println("After insertion print:"+s1);
		
		//empty stack elements
		while(!s1.empty()) {
			int popped=s1.pop();
			System.out.println("Element delete after each"+popped);
		}

		System.out.println("After delete of stack:"+s1);
 
	}
}


