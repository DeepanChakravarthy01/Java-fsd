package practiceproject9;
interface A{
		default void sun() {

			System.out.println("Hi all i am earth");
		}
	}

interface B{
		default void sun() {

			System.out.println("I am reloves around the sun daily");

		}
	}

	class C implements A,B{
		public void sun() {
			B.super.sun();
		}

	}

	public class Diamondstatement {

		public static void main(String[] args) {

			C obj=new C();
			obj.sun();
		}

	}





