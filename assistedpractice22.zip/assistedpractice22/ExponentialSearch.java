package assistedpractice22;

public class ExponentialSearch {
	
	public static int exponentialSearch(int[] arr, int target) {
        if (arr[0] == target) {
            return 0; // Element found at the first index
        }

        int bound = 1;
        int n = arr.length;

        while (bound < n && arr[bound] <= target) {
            bound *= 2; 
        }

        int left = bound / 2;
        int right = Math.min(bound, n - 1);

        return binarySearch(arr, target, left, right);
    }

    public static int binarySearch(int[] arr, int target, int left, int right) {
        while (left <= right) {
            int mid = left + (right - left) / 2;

            if (arr[mid] == target) {
                return mid; 
            } else if (arr[mid] < target) {
                left = mid + 1; 
            } else {
                right = mid - 1; 
            }
        }

        return -1; 
    }

    public static void main(String[] args) {
        int[] arr = {1000, 2000, 3000, 4000, 5000, 6000, 7000};
        int target = 4000;

        int index = exponentialSearch(arr, target);

        if (index != -1) {
            System.out.println("Num found at index " + index);
        } else {
            System.out.println("Num not found in the array.");
        }
    }
}


