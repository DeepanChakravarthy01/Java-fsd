package practiceproject5;

class CustomException extends Exception{
	public CustomException(String Message) {
		super(Message);
	}
}

public class ExceptionHandling {

	public static void main(String[] args) {
//throw class
		try {
			int dividend=9;
			int divisor=0;
			
			if(divisor==0) {
				throw new ArithmeticException(" Cannot divide by zero");
			}
			divideNumbers(dividend,divisor);
			
		//CustomException call
			int age=18;
			if(age<19) {
				throw new CustomException("You are not eligible for driving license");
			}
			
			
		}
		catch(ArithmeticException e) {
			System.out.println("ArithmeticException" +e.getMessage());
		}
		
		catch(CustomException e) {
			System.out.println("CustomException"+e.getMessage());
		}
		finally {
			System.out.println("Finally block is executed");
		}
	}

	private static void divideNumbers(int dividend, int divisor) {
		if(divisor==0) {
			throw new ArithmeticException("Cannot divide by zero");
		}
		int answer=dividend/divisor;
		System.out.println("Result of divide:"+answer);
	}

	
}

	


