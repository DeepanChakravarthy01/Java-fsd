package phase1project;
	
	public class Main {
		public static void main(String[] args) {
		CameraRentalApp app = new CameraRentalApp();
		app.run();
		}
		}


