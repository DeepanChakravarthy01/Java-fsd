package assistedpractice15;

class Node {
    int value;
    Node next;

    public Node(int valuea) {
        this.value = valuea;
        this.next = null;
    }
}

class DeleteinLL {
    private Node head;

    public DeleteinLL() {
        head = null;
    }

    // Insert a new node at the end of the list
    public void insert(int valuea) {
        Node n1 = new Node(valuea);
        if (head == null) {
            head = n1;
        } else {
            Node current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = n1;
        }
    }

    // Delete the first occurrence of a key
    public void delete(int key) {
        if (head == null) {
            System.out.println("List is empty. Deletion is not possible.");
            return;
        }

        if (head.value == key) {
            head = head.next;
            return;
        }

        Node current = head;
        while (current.next != null && current.next.value != key) {
            current = current.next;
        }

        if (current.next == null) {
            System.out.println("Key not found in the list.");
        } else {
            current.next = current.next.next;
        }
    }

    // the linked list
    public void display() {
        Node current = head;
        while (current != null) {
            System.out.print(current.value + " ");
            current = current.next;
        }
        System.out.println();
    }

    public static void main(String[] args) {
        DeleteinLL list = new DeleteinLL();
        list.insert(1);
        list.insert(4);
        list.insert(5);
        list.insert(5);
        list.insert(7);

        System.out.println("True Linked List:");
        list.display();

        int keyToDelete = 4;
        list.delete(keyToDelete);

        System.out.println("Linked List after delete " + keyToDelete + ":");
        list.display();
    }
}
