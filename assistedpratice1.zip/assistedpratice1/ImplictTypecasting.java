package assistedpratice1;
import java.util.Scanner;
public class ImplictTypecasting {
	public void convert(int var) {
				double implicit= var;
				
				System.out.println("Conversion of Integer to Double (Widening)  "+implicit);
				
			}
			public static void main(String[] args) {
				ImplictTypecasting imp=new ImplictTypecasting();
				Scanner sc=new Scanner(System.in);
				System.out.println("Enter an Integer Value: ");
				int variable=sc.nextInt();
				imp.convert(variable);
			}


	}

