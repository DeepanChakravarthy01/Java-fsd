package assistedpractice12;
import java.util.Arrays;

public class Fourthsmallestelement {
	public static void main(String[] args)
			{
			int[] unsortedList= {10,2,30,100,60,120,70,130,90};
			int fourthSmallest=findFourthSmallest(unsortedList);
			System.out.println("The fourth smallest number is: "+fourthSmallest);
			}

			public static int findFourthSmallest(int[] arr) 
			{
			if(arr.length<4) {
				
				return -1;
			}
			Arrays.sort(arr);
			return arr[3];
			}
}

		
