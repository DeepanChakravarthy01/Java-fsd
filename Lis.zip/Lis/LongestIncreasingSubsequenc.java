package Lis;

public class LongestIncreasingSubsequenc {
	
	public static int lis(int [] arr) {
		int n = arr.length;
	if (arr==null || n==0) {
		return 0;
		}
	int[] arr1=new int[n];
		 for (int i = 0; i < n; i++) {
		 arr1[i] = 1;
		 }
	for(int j=1;j<n;j++) {
	for(int i=0;i<j;i++) {
		if(arr[j]>arr[i]) {
	arr1[j]=Math.max(arr1[j],arr1[i]+1);
		}
		}
		}
		int max=0;
		for(int i=0;i<n;i++) {
		max=Math.max(max, arr1[i]);
		}
		return max;
		}
public static void main(String[] args) {
			
	int X1[]= {10,20,30,50,70,95,1,3,7,8};
		int X3[]= {1,5,8,12,18,7,9,10,55,3,6};
		int X2=lis(X3);
		System.out.println("Length of Lis are :"+X2);
		}
}


