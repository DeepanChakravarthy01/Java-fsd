/**
 * 
 */
/**
 * 
 */
module Phase2Practice6 {
	requires java.sql;
}