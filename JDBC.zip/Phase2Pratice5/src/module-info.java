/**
 * 
 */
/**
 * 
 */
module Phase2Pratice5 {
	requires java.sql;
}