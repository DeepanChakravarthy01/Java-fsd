/**
 * 
 */
/**
 * 
 */
module Phase2Practice3 {
	requires java.sql;
}