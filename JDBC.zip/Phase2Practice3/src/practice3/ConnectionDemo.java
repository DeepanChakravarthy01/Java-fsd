package practice3;


	import java.sql.Connection;
	import java.sql.DriverManager;
	import java.sql.ResultSet;
	import java.sql.SQLException;
	import java.sql.Statement;



	public class ConnectionDemo 
	{
	public static void main(String[] args) throws ClassNotFoundException, SQLException
	{
		final String DRIVER_CLASS="com.mysql.cj.jdbc.Driver";
	    final String DB_URL="jdbc:mysql://localhost:3306/data1";
		final String USERNAME="root";
		final String PASSWORD="Ammu@1703";
		Class.forName(DRIVER_CLASS);
		//connection with the dB 
		Connection con=DriverManager.getConnection(DB_URL,USERNAME,PASSWORD);
		Statement st=con.createStatement();
	 	ResultSet rs=st.executeQuery("select * from emp");
	 	while(rs.next())
		{
			System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getInt(3));//getter are present in resultset interface//getter method fetch the values based on the columnn number
		}
		con.close();
	 	
		
	}
	}


