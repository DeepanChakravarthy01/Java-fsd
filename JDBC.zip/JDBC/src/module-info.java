/**
 * 
 */
/**
 * 
 */
module JDBC {
	requires java.sql;
}