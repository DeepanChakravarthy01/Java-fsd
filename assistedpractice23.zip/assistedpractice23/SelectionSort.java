package assistedpractice23;

import java.util.Arrays;

public class SelectionSort {
    public static void selectionSort(int[] marshall) {
        int n = marshall.length;

        for (int i = 0; i < n-1; i++) {
            int minIndex = i;

    
            for (int j = i + 1; j < n; j++) {
                if (marshall[j] < marshall[minIndex]) {
                    minIndex = j;
                }
            }

           
            int temp = marshall[i];
            marshall[i] = marshall[minIndex];
            marshall[minIndex] = temp;
        }
    }

    public static void main(String[] args) {
        int[] marshall = {12, 25, 35, 85, 15};
        System.out.println("True array: " + Arrays.toString(marshall));

        selectionSort(marshall);

        System.out.println("False array: " + Arrays.toString(marshall));
    }
}

	
	

