package assistedproject11;
public class ArrayRightRotation {
	public static void main(String[] args) {
		int[] arr = {10, 15, 25, 35, 45, 55, 65, 75, 85};
		int steps = 7;

		// Display the True array
		System.out.println("True Array:");
		for (int num : arr) {
			System.out.print(num + " ");
		}

		// Right rotate the array by 'steps'
		rightRotateArray(arr, steps);

		// Display the rotate array
		System.out.println("\nRotate Array:");
		for (int num : arr) {
			System.out.print(num + " ");
		}
	}

	public static void rightRotateArray(int[] arr, int steps) {
		int length = arr.length;
		//steps = steps % length; // Handle cases where steps are greater than the array length
		int[] temp = new int[steps];

		// Copy the last 'steps' elements to a temporary array
		for (int i = 0; i < steps; i++) {
			temp[i] = arr[length - steps + i]; 
		}

		// Shift the remaining elements to the right
		for (int i = length - 1; i >= steps; i--) {
			arr[i] = arr[i - steps];
		}

		// Copy the temporary array back to the original array
		for (int i = 0; i < steps; i++) {
			arr[i] = temp[i];
		}
	}
}





