package projectcalculator;
import java.util.Scanner;
public class calculatorproject {
	public static void main(String[] args) {
			 Scanner sc = new Scanner(System.in);
			 System.out.println("Hi all welcome to Calculator");
			 double result = 0;
			 System.out.print("Enter the 1st number: ");
			 double number1 = sc.nextDouble();
			 System.out.print("Enter the 2nd number: ");
			 double number2 = sc.nextDouble();
			 System.out.println("\nSelect an operation to run:");
			 System.out.println("1. Addition (+)");
			 System.out.println("2. Subtraction (-)");
			 System.out.println("3. Multiplication (*)");
			 System.out.println("4. Division (/)");
			 System.out.print("Enter your choice : ");
			 int choice = sc.nextInt();
			 switch (choice) {
			 case 1:
			 result = number1 + number2;
			 System.out.println("Result: " + number1 + " + " + number2 +
			" = " + result);
			 break;
			 case 2:
			 result = number1 - number2;
			 System.out.println("Result: " + number1 + " - " + number2 +
			" = " + result);
			 break;
			 case 3:
			 result = number1 * number2;
			 System.out.println("Result: " + number1 + " * " + number2 +
			" = " + result);
			 break;
			 case 4:
			 if (number2 != 0) {
			 result = number1 / number2;
			 System.out.println("Result: " + number1 + " / " +
			number2 + " = " + result);
			 } else {
			 System.out.println("Cannot divide by zero");
			 }
			 break;
			 default:
			 System.out.println("Invalid choice!");
			 }

			 }
			}
	