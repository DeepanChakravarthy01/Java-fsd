package assistedpraticed2;

public class ProtctedFile {
	protected void display() {
		System.out.println("Hello protected access modifier");
	}
}

