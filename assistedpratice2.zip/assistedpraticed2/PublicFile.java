package assistedpraticed2;

public class PublicFile {
	public void display() {
		System.out.println("Hi public");
	}

}


