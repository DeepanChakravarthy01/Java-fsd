package assistedpraticed2;

public class DefaultFile {
	public void display() {
		System.out.println("Hello default");
	}
}



