package assistedpratice2;
import assistedpraticed2.*;
public class ProtectedAccessModifier extends ProtctedFile {

	public static void main(String[] args) {

		ProtectedAccessModifier pa=new ProtectedAccessModifier();
		pa.display();
	}

}


