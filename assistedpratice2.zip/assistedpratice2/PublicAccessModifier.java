package assistedpratice2;
import assistedpraticed2.*;

public class PublicAccessModifier {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PublicFile pf=new PublicFile();
		pf.display();
	}

}

	