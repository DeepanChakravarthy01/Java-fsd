package assistedpratice2;
class privateModifier{
	void display() {
		System.out.println("Hello private");
	}
}

public class PrivateAccessModifier {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		privateModifier a=new privateModifier();
		a.display();
		

	}

}
	