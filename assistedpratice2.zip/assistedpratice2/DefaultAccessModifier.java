package assistedpratice2;
import assistedpraticed2.*;

public class DefaultAccessModifier {

	public static void main(String[] args) {
		DefaultFile df=new DefaultFile();
		df.display();
		
	}

}


	