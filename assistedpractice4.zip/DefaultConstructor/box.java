package DefaultConstructor;

public class box {
	box(){
		double length=25;
		double breadth=35;
		double height=45;
		double volume=length*breadth*height;
		System.out.println("the volume of box: "+volume);
	}
}



