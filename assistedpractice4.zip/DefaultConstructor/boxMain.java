package DefaultConstructor;

public class boxMain {

	public static void main(String[] args) {
		box vol=new box();
		}

	}
