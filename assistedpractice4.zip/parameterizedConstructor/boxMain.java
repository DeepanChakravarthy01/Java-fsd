package parameterizedConstructor;
public class boxMain {
	public static void main(String[] args) {

		box vol=new box(25,35,45);
	}
}

