package DEEP;

public class box {
	void volume(double length,double breadth,double height) {
		double volume=length*breadth*height;
		System.out.println("The volume of the box is:"+volume);
	}
}


