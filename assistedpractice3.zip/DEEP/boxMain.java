package DEEP;

public class boxMain {

	public static void main(String[] args) {
			box details=new box();
			details.volume(30,40,50);

		}


	}


	