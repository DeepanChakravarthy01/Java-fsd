package DEEPPPP;

public class boxMain {

	public static void main(String[] args) {
		box details=new box();

		details.length=4;
		details.breadth=6;
		details.height=8;
		double volume=details.volume();
		System.out.println("final salary is -->"+volume);



	}

}


	