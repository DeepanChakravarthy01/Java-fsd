package DEEPPPP;

public class box {
double length,breadth,height;
	
	double volume() {
		return length*breadth*height;
		
	}

}



