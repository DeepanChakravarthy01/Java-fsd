package DEEPP;

public class boxMain {

	public static void main(String[] args) {
		box details=new box();
		details.length=30;
		details.height=40;
		details.breadth=50;
		details.volume();
	}

}


