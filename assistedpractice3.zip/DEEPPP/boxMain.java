package DEEPPP;

public class boxMain {

	public static void main(String[] args) {
		box details=new box();
		double volume=details.volume(13,6,8);

		System.out.println("The Volume of box :"+volume);
	}

}


