package DEEPPP;

public class box {
	double volume(double length,double breadth,double height) {
		return length*breadth*height;
	}
}


