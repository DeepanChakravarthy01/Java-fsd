package practiceproject8;

public class Abstraction {

	public static void main(String[] args) {
		
		CalcImplementation CalcImplementation=new CalcImplementation();
		CalcImplementation.sub(25,35);
	}

}

