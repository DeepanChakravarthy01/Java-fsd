package assistedpractice20;

public class LinearSearch {
	public static int ls(int[] arr, int target) {
        for (int x = 0; x < arr.length; x++) {
            if (arr[x] == target) {
                return x;
            }
        }
        return -1; 
    }

    public static void main(String[] args) {
        int[] arr = {100, 200, 300, 400, 500, 600};
        int target = 500;

        int index = ls(arr, target);

        if (index != -1) {
            System.out.println("num found in index " + index);
        } else {
            System.out.println("num not found in the array.");
        }
    }
}

